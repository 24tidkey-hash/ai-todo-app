# TaskMind AI — Intelligent To-Do List Application
> A complete AI-powered task management web application for college project submission.

---

## 📌 Project Description

TaskMind AI is a modern, intelligent to-do list application that combines traditional task management with AI-powered natural language processing. Users can add tasks using plain English like "Submit assignment by Friday at 6 PM" and the AI automatically extracts date, time, priority, category, and even suggests subtasks.

---

## ✨ Features

### Core Task Management
- ✅ Add, edit, delete tasks
- ✅ Mark tasks complete/incomplete
- ✅ Categories: Work, Study, Personal, Health, Finance
- ✅ Set due dates and times
- ✅ Priority levels: High / Medium / Low
- ✅ Subtasks (nested task items)
- ✅ LocalStorage persistence (data survives page refresh)

### AI Features (Powered by Claude API)
- ✅ Natural language input parsing
- ✅ Auto-extract date, time, priority from text
- ✅ Auto-categorize tasks from context
- ✅ Suggest relevant subtasks
- ✅ AI Chatbot assistant for task queries
- ✅ Productivity insights & analytics

### UI/UX
- ✅ Dark / Light mode toggle
- ✅ Fully responsive (mobile + desktop)
- ✅ Search & filter tasks
- ✅ Sort by date, priority, creation time
- ✅ Calendar view with task indicators
- ✅ Productivity stats dashboard
- ✅ Progress bar visualization
- ✅ Toast notifications
- ✅ Voice input (Web Speech API)
- ✅ Browser notifications for reminders

---

## 🛠 Technologies Used

| Layer      | Technology             |
|------------|------------------------|
| Frontend   | HTML5, CSS3, JavaScript (Vanilla) |
| AI/NLP     | Anthropic Claude API (claude-sonnet-4) |
| Storage    | LocalStorage (browser-native) |
| Voice      | Web Speech API (browser-native) |
| Fonts      | Google Fonts (Syne + DM Sans) |
| Deployment | Static HTML — no server needed |

---

## 📁 Folder Structure

```
ai-todo-app/
├── index.html        # Complete application (single file)
└── README.md         # This file
```

---

## 🚀 Installation & Running

### Option 1 — Open directly (simplest)
1. Download `index.html`
2. Double-click to open in any browser (Chrome/Edge recommended)
3. The app works immediately with sample data

### Option 2 — Local server (recommended for full AI features)
```bash
# Python
python -m http.server 8080

# Node.js
npx serve .

# Then open: http://localhost:8080
```

### Option 3 — Deploy online
Upload `index.html` to any static hosting:
- GitHub Pages
- Netlify (drag & drop)
- Vercel

---

## 🤖 AI Features Setup

The app calls the **Anthropic Claude API** for:
1. Natural language task parsing
2. AI chatbot responses

The API is configured to work in the browser. For production use, proxy API calls through a backend to protect your API key.

**Fallback**: If the API is unavailable, the app uses a built-in rule-based parser that still correctly handles most natural language patterns.

---

## 🎮 How to Use

### Adding a Task with AI
Type naturally in the input box:
- `"Complete physics assignment by tomorrow evening, high priority"`
- `"Buy groceries today"`
- `"Team meeting on Friday at 2 PM"`
- `"Prepare for exam next Monday"`

Press **Ctrl+Enter** or click **✦ Parse & Add**

The AI will automatically set:
- Task title (cleaned)
- Category (inferred)
- Priority level
- Due date & time
- Suggested subtasks

### AI Chat Assistant
Click the 🤖 button (top right) to open the AI chat. Ask:
- *"What tasks are overdue?"*
- *"How productive have I been this week?"*
- *"Give me a tip to manage my workload"*

### Views & Filters
- **Filter tabs**: All / Active / Done / Overdue
- **Search**: Real-time task search
- **Sort**: By date, priority, or newest
- **Calendar** 📅: Month view with task dots
- **Insights** 📊: Completion rate, streak, stats

---

## 📊 Project Architecture

```
User Input (Natural Language)
        │
        ▼
┌─────────────────────┐
│  AI Parse Layer     │  ←── Claude API / Fallback Parser
│  (NLP Extraction)   │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  Task State Manager │  ←── In-memory + LocalStorage
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│  UI Render Engine   │  ←── DOM manipulation
└─────────────────────┘
```

---

## 👨‍💻 Author

- **Project**: TaskMind AI
- **Type**: College Project — Full-Stack Web Application
- **Tech Stack**: HTML + CSS + JS + Claude AI API

---

## 📄 License

MIT License — Free to use, modify, and distribute for educational purposes.
